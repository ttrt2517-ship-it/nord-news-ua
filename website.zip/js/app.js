/**
 * NORD - Main JavaScript
 */

// Theme Management
const ThemeManager = {
    init() {
        const saved = localStorage.getItem('nord-theme') || 'light';
        document.documentElement.setAttribute('data-theme', saved);
        this.bindToggle();
    },
    
    bindToggle() {
        const toggle = document.querySelector('.theme-toggle');
        if (toggle) {
            toggle.addEventListener('click', () => this.toggle());
        }
    },
    
    toggle() {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'light' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('nord-theme', next);
    }
};

// Language Switcher
const LangManager = {
    current: 'ua',
    
    init() {
        const saved = localStorage.getItem('nord-lang') || 'ua';
        this.current = saved;
        this.updateUI();
        this.bindButtons();
    },
    
    bindButtons() {
        document.querySelectorAll('.lang-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const lang = btn.dataset.lang;
                this.setLanguage(lang);
            });
        });
    },
    
    setLanguage(lang) {
        this.current = lang;
        localStorage.setItem('nord-lang', lang);
        this.updateUI();
        // Reload content with new language
        ArticleManager.load({ lang });
    },
    
    updateUI() {
        document.querySelectorAll('.lang-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.lang === this.current);
        });
        document.documentElement.lang = this.current === 'ua' ? 'uk' : this.current;
    }
};

// Mobile Menu
const MobileMenu = {
    init() {
        const toggle = document.querySelector('.menu-toggle');
        const menu = document.querySelector('.mobile-menu');
        
        if (toggle && menu) {
            toggle.addEventListener('click', () => {
                menu.classList.toggle('active');
                toggle.classList.toggle('active');
            });
        }
    }
};

// Article Management
const ArticleManager = {
    page: 1,
    loading: false,
    
    async init() {
        await this.load();
        this.bindLoadMore();
    },
    
    async load(options = {}) {
        if (this.loading) return;
        this.loading = true;
        
        const lang = options.lang || LangManager.current;
        const page = options.page || 1;
        
        try {
            const response = await fetch(`/api/articles.php?lang=${lang}&page=${page}`);
            const data = await response.json();
            
            if (page === 1) {
                this.renderFeatured(data.featured);
                this.renderArticles(data.articles);
            } else {
                this.appendArticles(data.articles);
            }
            
            this.page = page;
        } catch (error) {
            console.error('Failed to load articles:', error);
        } finally {
            this.loading = false;
        }
    },
    
    renderFeatured(article) {
        const container = document.getElementById('featured');
        if (!article) {
            container.innerHTML = '';
            return;
        }
        
        container.innerHTML = `
            <article class="featured-article">
                <div class="featured-image" style="background-image: url('${article.image}')"></div>
                <div class="featured-content">
                    <span class="category-badge">${article.category}</span>
                    <h1 class="featured-title">${article.title}</h1>
                    <p class="featured-excerpt">${article.excerpt}</p>
                    <div class="featured-meta">
                        <span class="source">${article.source}</span>
                        <span class="time">${this.formatTime(article.published_at)}</span>
                    </div>
                    <a href="/article/${article.slug}/" class="read-more">Читати далі →</a>
                </div>
            </article>
        `;
    },
    
    renderArticles(articles) {
        const container = document.getElementById('articles-grid');
        container.innerHTML = articles.map(a => this.articleCard(a)).join('');
    },
    
    appendArticles(articles) {
        const container = document.getElementById('articles-grid');
        container.innerHTML += articles.map(a => this.articleCard(a)).join('');
    },
    
    articleCard(article) {
        return `
            <article class="article-card">
                <div class="article-card-image" style="background-image: url('${article.image}')"></div>
                <div class="article-card-content">
                    <h3 class="article-card-title">
                        <a href="/article/${article.slug}/">${article.title}</a>
                    </h3>
                    <p class="article-card-excerpt">${article.excerpt}</p>
                    <div class="article-card-meta">
                        <span>${article.source}</span>
                        <span>${this.formatTime(article.published_at)}</span>
                    </div>
                </div>
            </article>
        `;
    },
    
    formatTime(dateStr) {
        const date = new Date(dateStr);
        const now = new Date();
        const diff = Math.floor((now - date) / 1000 / 60); // minutes
        
        if (diff < 60) return `${diff} хв тому`;
        if (diff < 24 * 60) return `${Math.floor(diff / 60)} год тому`;
        if (diff < 7 * 24 * 60) return `${Math.floor(diff / 60 / 24)} днів тому`;
        
        return date.toLocaleDateString('uk-UA');
    },
    
    bindLoadMore() {
        const btn = document.getElementById('load-more');
        if (btn) {
            btn.addEventListener('click', () => {
                btn.classList.add('loading');
                this.load({ page: this.page + 1 }).then(() => {
                    btn.classList.remove('loading');
                });
            });
        }
    }
};

// Products Banner
const ProductsManager = {
    async init() {
        await this.load();
    },
    
    async load() {
        try {
            const response = await fetch('api/products.php');
            const products = await response.json();
            this.render(products);
        } catch (error) {
            console.error('Failed to load products:', error);
        }
    },
    
    render(products) {
        const container = document.getElementById('products-banner');
        if (!container || products.length === 0) return;
        
        container.innerHTML = `
            <h3>🎯 Рекомендуємо</h3>
            <div class="products-list">
                ${products.map(p => `
                    <a href="${p.url}" target="_blank" class="product-link">
                        ${p.title}
                    </a>
                `).join(' • ')}
            </div>
        `;
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    ThemeManager.init();
    LangManager.init();
    MobileMenu.init();
    ArticleManager.init();
    ProductsManager.init();
});
